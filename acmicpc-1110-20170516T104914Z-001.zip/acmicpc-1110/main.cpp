#include <stdio.h>

using namespace std;

int main()
{
    int original, num, num1, num2, num3;
    int counter = 0;
    scanf("%d", &num);

    if(num >= 0 || num <=99)
    {

        original = num;
        //cout << "Before num : " << num << endl;

        num1 = num / 10;
        num2 = num % 10;
        num3 = num1 + num2;
        num = num2 * 10 + num3;

        //cout << "num1 : " << num1 << endl;
        //cout << "num2 : " << num2 << endl;
        //cout << "num3 : " << num3 << endl;
        //cout << "After num : " << num << endl;
        counter++;

        while(original != num)
        {
            //cout << "Before num : " << num << endl;

            num1 = num / 10;
            num2 = num % 10;
            num3 = num1 + num2;
            num = num2 * 10 + num3 % 10;

            //cout << "num1 : " << num1 << endl;
            //cout << "num2 : " << num2 << endl;
            //cout << "num3 : " << num3 << endl;
            //cout << "After num : " << num << endl;
            ++counter;
        }
    }

    printf("%d", counter);

    return 0;
}
